package com.example.advice;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.json.JsonMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.openhtmltopdf.pdfboxout.PdfRendererBuilder;
import com.openhtmltopdf.outputdevice.helper.BaseRendererBuilder.FontStyle;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.ClassLoaderTemplateResolver;

import java.io.*;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.text.NumberFormat;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;

/** JSON -> validated DTO -> trusted Thymeleaf XHTML -> PDF. Java 17+. */
public final class AdvicePdfGenerator {
    public record Transaction(String reference, String customerName, String currency, BigDecimal amount) {}
    public record Attachment(String fileName, String downloadUrl) {}
    public record Message(String kind, String author, String role, OffsetDateTime timestamp,
                          String text, List<Attachment> attachments) {
        public Message { attachments = attachments == null ? List.of() : List.copyOf(attachments); }
        public Message(String kind, String author, String role, OffsetDateTime timestamp, String text) {
            this(kind, author, role, timestamp, text, List.of());
        }
    }
    public record Query(String id, String subject, String status, List<Message> messages) {}
    public record Advice(String adviceNumber, OffsetDateTime generatedAt, String displayZone,
                         Transaction transaction, List<Query> queries) {}

    private final ObjectMapper mapper = JsonMapper.builder().addModule(new JavaTimeModule())
            .enable(DeserializationFeature.FAIL_ON_TRAILING_TOKENS).build();
    private final TemplateEngine engine;

    public AdvicePdfGenerator() {
        ClassLoaderTemplateResolver resolver = new ClassLoaderTemplateResolver();
        resolver.setPrefix("templates/");
        resolver.setSuffix(".xhtml");
        resolver.setTemplateMode(TemplateMode.XML); // well-formed XHTML, no HTML repair
        resolver.setCharacterEncoding(StandardCharsets.UTF_8.name());
        resolver.setCacheable(true);
        engine = new TemplateEngine();
        engine.setTemplateResolver(resolver);
    }

    public Advice read(InputStream json) throws IOException {
        return validate(mapper.readValue(json, Advice.class));
    }

    public String renderXhtml(Advice input) {
        Advice advice = validate(input);
        Context context = new Context(Locale.UK);
        context.setVariable("advice", advice);
        context.setVariable("fmt", new Formats(ZoneId.of(advice.displayZone())));
        context.setVariable("replyCount", advice.queries().stream()
                .mapToInt(q -> q.messages().size() - 1).sum());
        return engine.process("query-advice", context);
    }

    /** Does not close the caller's stream. Create a fresh renderer for every PDF. */
    public void generate(Advice advice, OutputStream output) throws IOException {
        String xhtml = renderXhtml(advice);
        PdfRendererBuilder builder = new PdfRendererBuilder();
        builder.withHtmlContent(xhtml, null); // self-contained template; no external assets
        builder.useFont(() -> resource("fonts/DejaVuSans.ttf"), "Advice Sans", 400, FontStyle.NORMAL, true);
        builder.useFont(() -> resource("fonts/DejaVuSans-Bold.ttf"), "Advice Sans", 700, FontStyle.NORMAL, true);
        // This renderer needs no network or local-file resources. Fonts are supplied above.
        builder.useExternalResourceAccessControl((uri, type) -> false,
                com.openhtmltopdf.outputdevice.helper.ExternalResourceControlPriority.RUN_BEFORE_RESOLVING_URI);
        builder.useExternalResourceAccessControl((uri, type) -> false,
                com.openhtmltopdf.outputdevice.helper.ExternalResourceControlPriority.RUN_AFTER_RESOLVING_URI);
        builder.toStream(output);
        builder.run();
    }

    private static InputStream resource(String name) {
        InputStream stream = AdvicePdfGenerator.class.getClassLoader().getResourceAsStream(name);
        if (stream == null) throw new IllegalStateException("Missing classpath resource: " + name);
        return stream;
    }

    private static Advice validate(Advice a) {
        Objects.requireNonNull(a, "Advice is required");
        required(a.adviceNumber(), "adviceNumber");
        Objects.requireNonNull(a.generatedAt(), "generatedAt is required (ISO-8601 with offset)");
        required(a.displayZone(), "displayZone");
        ZoneId.of(a.displayZone());
        Transaction t = Objects.requireNonNull(a.transaction(), "transaction is required");
        required(t.reference(), "transaction.reference");
        required(t.customerName(), "transaction.customerName");
        required(t.currency(), "transaction.currency");
        Currency currency = Currency.getInstance(t.currency());
        Objects.requireNonNull(t.amount(), "transaction.amount is required");
        if (t.amount().signum() < 0) throw new IllegalArgumentException("amount cannot be negative");
        if (currency.getDefaultFractionDigits() < 0) throw new IllegalArgumentException("Unsupported currency");
        t.amount().setScale(currency.getDefaultFractionDigits(), java.math.RoundingMode.UNNECESSARY);
        Objects.requireNonNull(a.queries(), "queries is required (an empty array is allowed)");
        Set<String> ids = new HashSet<>();
        List<Query> queries = new ArrayList<>();
        for (Query q : a.queries()) {
            Objects.requireNonNull(q, "query cannot be null");
            required(q.id(), "query.id");
            if (q.subject() != null && !q.subject().isBlank()) required(q.subject(), "query.subject");
            if (!ids.add(q.id())) throw new IllegalArgumentException("Duplicate query id: " + q.id());
            if (!Set.of("OPEN", "RESOLVED").contains(q.status() == null ? "" : q.status()))
                throw new IllegalArgumentException("Query status must be OPEN or RESOLVED");
            if (q.messages() == null || q.messages().isEmpty())
                throw new IllegalArgumentException("Each query needs an initial QUERY message");
            List<Message> messages = new ArrayList<>(q.messages());
            for (Message m : messages) {
                Objects.requireNonNull(m, "message cannot be null");
                required(m.author(), "message.author"); required(m.role(), "message.role");
                if (m.text() == null || m.text().isBlank()) {
                    if (m.attachments().isEmpty()) throw new IllegalArgumentException("Message needs text or attachments");
                } else required(m.text(), "message.text");
                for (Attachment attachment : m.attachments()) {
                    required(attachment.fileName(), "attachment.fileName");
                    required(attachment.downloadUrl(), "attachment.downloadUrl");
                    java.net.URI uri = java.net.URI.create(attachment.downloadUrl());
                    if (!"https".equalsIgnoreCase(uri.getScheme()) || uri.getHost() == null ||
                            uri.getUserInfo() != null || uri.getFragment() != null)
                        throw new IllegalArgumentException("Attachment downloadUrl must be an absolute HTTPS URL without credentials or fragment");
                }
                Objects.requireNonNull(m.timestamp(), "message.timestamp is required");
                if (!Set.of("QUERY", "REPLY", "FOLLOW_UP").contains(m.kind() == null ? "" : m.kind()))
                    throw new IllegalArgumentException("Message kind must be QUERY, REPLY or FOLLOW_UP");
                if (m.timestamp().isAfter(a.generatedAt()))
                    throw new IllegalArgumentException("A message cannot be later than generatedAt");
            }
            messages.sort(Comparator.comparing(m -> m.timestamp().toInstant()));
            if (!"QUERY".equals(messages.get(0).kind()) ||
                    messages.stream().filter(m -> "QUERY".equals(m.kind())).count() != 1)
                throw new IllegalArgumentException("Each thread must start with exactly one QUERY");
            queries.add(new Query(q.id(), q.subject(), q.status(), List.copyOf(messages)));
        }
        // Threads ordered by when they were raised; each thread's messages ordered chronologically.
        queries.sort(Comparator.comparing(q -> q.messages().get(0).timestamp().toInstant()));
        return new Advice(a.adviceNumber(), a.generatedAt(), a.displayZone(), t, List.copyOf(queries));
    }

    private static void required(String value, String field) {
        if (value == null || value.isBlank()) throw new IllegalArgumentException(field + " is required");
        if (value.codePoints().anyMatch(c -> !(c == 9 || c == 10 || c == 13 ||
                (c >= 32 && c <= 0xD7FF) || (c >= 0xE000 && c <= 0xFFFD) ||
                (c >= 0x10000 && c <= 0x10FFFF))))
            throw new IllegalArgumentException(field + " contains an invalid XML character");
    }

    public static final class Formats {
        private final ZoneId zone;
        private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("dd MMM yyyy, HH:mm z", Locale.UK);
        public Formats(ZoneId zone) { this.zone = zone; }
        public String time(OffsetDateTime value) { return TIME.format(value.atZoneSameInstant(zone)); }
        public String amount(Transaction t) {
            NumberFormat number = NumberFormat.getNumberInstance(Locale.UK);
            int digits = Currency.getInstance(t.currency()).getDefaultFractionDigits();
            number.setMinimumFractionDigits(digits); number.setMaximumFractionDigits(digits);
            return t.currency() + " " + number.format(t.amount());
        }
        // Insert soft wrap opportunities without accepting HTML; th:text still escapes everything.
        public String body(String value) {
            StringBuilder out = new StringBuilder(); int run = 0;
            for (int cp : value.codePoints().toArray()) {
                out.appendCodePoint(cp);
                if (Character.isWhitespace(cp)) run = 0;
                else if (++run == 40) { out.append('\u200B'); run = 0; }
            }
            return out.toString();
        }
    }

    public static void main(String[] args) throws Exception {
        if (args.length != 2) {
            System.err.println("Usage: java -jar advice-pdf-1.0.0.jar input.json output.pdf");
            System.exit(2);
        }
        AdvicePdfGenerator generator = new AdvicePdfGenerator();
        Advice advice;
        try (InputStream in = Files.newInputStream(Path.of(args[0]))) { advice = generator.read(in); }
        Path destination = Path.of(args[1]).toAbsolutePath();
        Files.createDirectories(destination.getParent());
        // Avoid leaving a partial PDF on failure, and keep an existing destination until success.
        Path temporary = Files.createTempFile(destination.getParent(), "advice-", ".pdf");
        try {
            try (OutputStream out = Files.newOutputStream(temporary)) { generator.generate(advice, out); }
            try { Files.move(temporary, destination, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING); }
            catch (AtomicMoveNotSupportedException e) { Files.move(temporary, destination, StandardCopyOption.REPLACE_EXISTING); }
        } finally { Files.deleteIfExists(temporary); }
        System.out.println("Created " + destination);
    }
}
