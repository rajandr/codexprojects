package com.example.advice;

import com.example.advice.AdvicePdfGenerator.*;
import org.apache.pdfbox.Loader;
import org.apache.pdfbox.text.PDFTextStripper;
import org.junit.jupiter.api.Test;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;

class AdvicePdfGeneratorTest {
    private final AdvicePdfGenerator generator = new AdvicePdfGenerator();
    private Advice sample() throws Exception {
        try (InputStream in = Files.newInputStream(Path.of("samples/advice.json"))) { return generator.read(in); }
    }
    private static String normalise(String text) {
        return java.text.Normalizer.normalize(text, java.text.Normalizer.Form.NFKC).replaceAll("\\s+", " ");
    }
    @Test void rendersTransactionAndEveryMessage() throws Exception {
        Advice a = sample();
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        generator.generate(a, out);
        try (var pdf = Loader.loadPDF(out.toByteArray())) {
            String text = normalise(new PDFTextStripper().getText(pdf));
            assertTrue(text.contains("XLB202610300018"));
            assertTrue(text.contains("USD 125,000.00"));
            assertTrue(text.contains("Meridian Exports Private Limited"));
            for (Query q : a.queries()) for (Message m : q.messages()) {
                assertTrue(text.contains(m.author()));
                String beginning = m.text().substring(0, Math.min(25, m.text().length()));
                assertTrue(text.contains(normalise(beginning)), "Missing message by " + m.author());
            }
            assertTrue(text.contains("IST"));
            assertTrue(text.contains("End of communication record"));
        }
    }
    @Test void escapesMarkupAndKeepsNewlines() throws Exception {
        Advice a = sample(); Message original = a.queries().get(0).messages().get(0);
        String body = "<script>alert('test')</script> & invoice\nSecond line";
        Message m = new Message("QUERY", original.author(), original.role(), original.timestamp(), body);
        Advice changed = new Advice(a.adviceNumber(), a.generatedAt(), a.displayZone(), a.transaction(),
                List.of(new Query("Q-escape", "A & B <review>", "OPEN", List.of(m))));
        String xml = generator.renderXhtml(changed);
        assertFalse(xml.contains("<script>")); assertTrue(xml.contains("&lt;script&gt;"));
        ByteArrayOutputStream out = new ByteArrayOutputStream(); generator.generate(changed, out);
        try (var pdf = Loader.loadPDF(out.toByteArray())) {
            String text = normalise(new PDFTextStripper().getText(pdf));
            assertTrue(text.contains("<script>alert('test')</script> & invoice"));
            assertTrue(text.contains("Second line"));
        }
    }
    @Test void longSingleMessageSplitsAcrossPagesWithoutDroppingText() throws Exception {
        Advice a = sample(); Message m = a.queries().get(0).messages().get(0);
        String text = ("Please review the supporting documents and confirm the discrepancy.\n").repeat(160) + "FINAL-LINE-160";
        Advice longAdvice = new Advice(a.adviceNumber(), a.generatedAt(), a.displayZone(), a.transaction(),
                List.of(new Query("Q-long", "Long conversation", "OPEN",
                        List.of(new Message("QUERY", m.author(), m.role(), m.timestamp(), text)))));
        ByteArrayOutputStream out = new ByteArrayOutputStream(); generator.generate(longAdvice, out);
        try (var pdf = Loader.loadPDF(out.toByteArray())) {
            assertTrue(pdf.getNumberOfPages() >= 3);
            PDFTextStripper stripper = new PDFTextStripper();
            String extracted = stripper.getText(pdf);
            assertEquals(160, extracted.split("Please review the supporting", -1).length - 1);
            assertTrue(extracted.contains("FINAL-LINE-160"));
            for (int page = 1; page <= pdf.getNumberOfPages(); page++) {
                stripper.setStartPage(page); stripper.setEndPage(page);
                String onePage = stripper.getText(pdf);
                assertTrue(onePage.contains("XLB202610300018"));
                assertTrue(onePage.contains("Page " + page + " of " + pdf.getNumberOfPages()));
            }
        }
    }
    @Test void rejectsRepliesEarlierThanTheQueryAndDuplicateIds() throws Exception {
        Advice a = sample(); Query q = a.queries().get(0); Message first = q.messages().get(0);
        Message reply = new Message("REPLY", "Operations", "Back Office", first.timestamp().minusMinutes(1), "Early reply");
        Advice bad = new Advice(a.adviceNumber(), a.generatedAt(), a.displayZone(), a.transaction(),
                List.of(new Query(q.id(), q.subject(), q.status(), List.of(first, reply))));
        assertThrows(IllegalArgumentException.class, () -> generator.renderXhtml(bad));
        Advice duplicate = new Advice(a.adviceNumber(), a.generatedAt(), a.displayZone(), a.transaction(), List.of(q, q));
        assertThrows(IllegalArgumentException.class, () -> generator.renderXhtml(duplicate));
    }
    @Test void emptyHistoryIsValidAndUnansweredQueryIsValid() throws Exception {
        Advice a = sample();
        String xml = generator.renderXhtml(new Advice(a.adviceNumber(), a.generatedAt(), a.displayZone(), a.transaction(), List.of()));
        assertTrue(xml.contains("No queries recorded"));
        Query q = a.queries().get(0);
        assertDoesNotThrow(() -> generator.renderXhtml(new Advice(a.adviceNumber(), a.generatedAt(), a.displayZone(), a.transaction(),
                List.of(new Query(q.id(), q.subject(), "OPEN", List.of(q.messages().get(0)))))));
    }
    @Test void attachmentLinksExistInPdfAndSubjectsAreOptional() throws Exception {
        Advice a = sample();
        String xml = generator.renderXhtml(a);
        assertFalse(xml.contains("class=\"thread-title\""));
        int expected = a.queries().stream().flatMap(q -> q.messages().stream()).mapToInt(m -> m.attachments().size()).sum();
        ByteArrayOutputStream out = new ByteArrayOutputStream(); generator.generate(a, out);
        Set<String> urls = new HashSet<>(); int count = 0;
        try (var pdf = Loader.loadPDF(out.toByteArray())) {
            String text = normalise(new PDFTextStripper().getText(pdf));
            for (Query q : a.queries()) for (Message m : q.messages()) for (Attachment attachment : m.attachments())
                assertTrue(text.contains(attachment.fileName()));
            for (var page : pdf.getPages()) for (var annotation : page.getAnnotations())
                if (annotation instanceof org.apache.pdfbox.pdmodel.interactive.annotation.PDAnnotationLink link &&
                        link.getAction() instanceof org.apache.pdfbox.pdmodel.interactive.action.PDActionURI action) {
                    count++; urls.add(action.getURI());
                }
        }
        assertEquals(expected, count);
        for (Query q : a.queries()) for (Message m : q.messages()) for (Attachment attachment : m.attachments())
            assertTrue(urls.contains(attachment.downloadUrl()));
    }
    @Test void attachmentOnlyMessagesAndEscapedUrlsWorkAndUnsafeUrlsAreRejected() throws Exception {
        Advice a = sample(); Message m = a.queries().get(0).messages().get(0);
        String url = "https://documents.example.com/download?id=123&version=2";
        Message attached = new Message("QUERY", m.author(), m.role(), m.timestamp(), null,
                List.of(new Attachment("Invoice & schedule.pdf", url)));
        Advice changed = new Advice(a.adviceNumber(), a.generatedAt(), a.displayZone(), a.transaction(),
                List.of(new Query("Q-attachment", "   ", "OPEN", List.of(attached))));
        String xml = generator.renderXhtml(changed);
        assertTrue(xml.contains("id=123&amp;version=2"));
        assertFalse(xml.contains("class=\"thread-title\""));
        ByteArrayOutputStream out = new ByteArrayOutputStream(); generator.generate(changed, out);
        try (var pdf = Loader.loadPDF(out.toByteArray())) {
            var link = (org.apache.pdfbox.pdmodel.interactive.annotation.PDAnnotationLink) pdf.getPage(0).getAnnotations().get(0);
            assertEquals(url, ((org.apache.pdfbox.pdmodel.interactive.action.PDActionURI) link.getAction()).getURI());
        }
        Message unsafe = new Message("QUERY", m.author(), m.role(), m.timestamp(), "See attachment",
                List.of(new Attachment("Bad.pdf", "javascript:alert(1)")));
        Advice bad = new Advice(a.adviceNumber(), a.generatedAt(), a.displayZone(), a.transaction(),
                List.of(new Query("Q-bad", null, "OPEN", List.of(unsafe))));
        assertThrows(IllegalArgumentException.class, () -> generator.renderXhtml(bad));
    }
}
