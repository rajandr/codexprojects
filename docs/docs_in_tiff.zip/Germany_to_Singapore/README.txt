SCANNED TIFF TEST SET

Documents 01-09 are grayscale TIFF images at 300 DPI with lossless LZW compression. They are intended to behave like scanned trade documents for OCR, IDR, classification, deskew/rotation, document-quality and extraction testing.

MT700 is retained as PDF because SWIFT MT700 is an electronic message rather than a scanned trade document.

All documents are fictional samples and are not valid for commercial, banking, customs or legal use.
